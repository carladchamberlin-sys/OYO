﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmMain))
        soulPlayer = New PictureBox()
        Timer1 = New Timer(components)
        particleTimer = New Timer(components)
        CType(soulPlayer, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' soulPlayer
        ' 
        soulPlayer.Image = My.Resources.Resources.Soul
        soulPlayer.Location = New Point(62, 62)
        soulPlayer.Name = "soulPlayer"
        soulPlayer.Size = New Size(25, 25)
        soulPlayer.SizeMode = PictureBoxSizeMode.Zoom
        soulPlayer.TabIndex = 0
        soulPlayer.TabStop = False
        ' 
        ' Timer1
        ' 
        Timer1.Enabled = True
        Timer1.Interval = 1
        ' 
        ' particleTimer
        ' 
        particleTimer.Interval = 1
        ' 
        ' FrmMain
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Black
        BackgroundImage = My.Resources.Resources.Box
        BackgroundImageLayout = ImageLayout.Zoom
        ClientSize = New Size(150, 150)
        Controls.Add(soulPlayer)
        DoubleBuffered = True
        FormBorderStyle = FormBorderStyle.None
        Icon = CType(resources.GetObject("$this.Icon"), Icon)
        Name = "FrmMain"
        StartPosition = FormStartPosition.CenterScreen
        CType(soulPlayer, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents soulPlayer As PictureBox
    Friend WithEvents Timer1 As Timer
    Friend WithEvents particleTimer As Timer

End Class

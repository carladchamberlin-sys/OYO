﻿Imports System.Drawing
Imports System.Media
Imports System.Runtime.InteropServices
Imports System.Threading

Public Class FrmMain
    Declare Function GetAsyncKeyState Lib "user32" (ByVal vKey As System.Windows.Forms.Keys) As Short
    Dim moveSpeed = 1
    Dim soulStop = 0
    Dim offScreen = False
    Private particles As New List(Of SoulParticle)
    Private rand As New Random()

    Private Class SoulParticle

        Public Sprite As PictureBox

        Public VelocityX As Double
        Public VelocityY As Double

        Public Gravity As Double = 0.18

        Public PositionX As Double
        Public PositionY As Double

    End Class
    Private Sub ShatterSoul()
        Dim soulScreenPosition As Point = soulPlayer.PointToScreen(Point.Empty)

        Dim soulCenterX As Integer =
        soulPlayer.Left + soulPlayer.Width \ 2

        Dim soulCenterY As Integer =
        soulPlayer.Top + soulPlayer.Height \ 2

        soulPlayer.Visible = False

        Dim shardImages As Image() = {
        My.Resources.Shard1,
        My.Resources.Shard2,
        My.Resources.Shard3,
        My.Resources.Shard4
    }
        Dim newSoulPosition As Point = Me.PointToClient(soulScreenPosition)

        For i As Integer = 0 To 6

            Dim particle As New SoulParticle()

            Dim shard As New PictureBox()

            shard.Image = shardImages(rand.Next(shardImages.Length))
            shard.SizeMode = PictureBoxSizeMode.Zoom
            shard.Size = New Size(12, 12)

            particle.PositionX = soulCenterX - shard.Width / 2.0 + rand.Next(-5, 6)
            particle.PositionY = soulCenterY - shard.Height / 2.0 + rand.Next(-5, 6)

            particle.VelocityX = rand.NextDouble() * 7 - 3.5
            particle.VelocityY = -(rand.NextDouble() * 4 + 1)

            shard.Location = New Point(
            CInt(particle.PositionX),
            CInt(particle.PositionY)
        )

            particle.Sprite = shard

            Me.Controls.Add(shard)
            shard.BringToFront()

            particles.Add(particle)

        Next

        particleTimer.Start()

    End Sub

    Public Function IsWindowOnScreen() As Boolean
        Dim winRect As New Rectangle(Me.Left, Me.Top, Me.Width, Me.Height)

        For Each scr As Screen In Screen.AllScreens
            If scr.WorkingArea.IntersectsWith(winRect) Then
                Return True
            End If
        Next

        Return False
    End Function

    Private Async Sub soulPlayer_Click(sender As Object, e As EventArgs) Handles soulPlayer.Click
        Dim screenPoint As Point = Me.PointToScreen(soulPlayer.Location)
        soulPlayer.Location = screenPoint

        soulStop = 1
        soulPlayer.Size = New Size(25, 25)
        Me.BackgroundImage = Nothing
        Me.Size = Screen.PrimaryScreen.Bounds.Size
        Me.Location = Screen.PrimaryScreen.Bounds.Location
        Await Task.Delay(500)
        soulPlayer.Image = My.Resources.SoulBreak
        soulPlayer.Size = New Size(30, 25)
        soulPlayer.Left -= 2.5
        My.Computer.Audio.Play("C:\Users\banan\source\repos\OnYourOwn Solution\OnYourOwn Project\Resources\break.wav", AudioPlayMode.Background)
        Await Task.Delay(1500)
        soulPlayer.Visible = False
        ShatterSoul()
        My.Computer.Audio.Play("C:\Users\banan\source\repos\OnYourOwn Solution\OnYourOwn Project\Resources\shatter.wav", AudioPlayMode.Background)
        Await Task.Delay(3000)
        Me.Close()
    End Sub
    <DllImport("user32.dll")>
    Private Shared Function MonitorFromWindow(hwnd As IntPtr, dwFlags As UInteger) As IntPtr
    End Function

    Private Const MONITOR_DEFAULTTONULL As UInteger = &H0

    Public Function IsWindowOffScreen(hWnd As IntPtr) As Boolean
        Dim hMonitor As IntPtr = MonitorFromWindow(hWnd, MONITOR_DEFAULTTONULL)
        Return hMonitor = IntPtr.Zero
    End Function

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If GetAsyncKeyState(Keys.W) <> 0 And soulStop <> 1 And soulPlayer.Top <= 5 Then
            Me.Top -= 0.75 / moveSpeed
        ElseIf GetAsyncKeyState(Keys.W) And soulStop <> 1 Then
            soulPlayer.Top -= 1.5 / moveSpeed
        End If
        If GetAsyncKeyState(Keys.A) <> 0 And soulStop <> 1 And soulPlayer.Left <= 5 Then
            Me.Left -= 0.75 / moveSpeed
        ElseIf GetAsyncKeyState(Keys.A) And soulStop <> 1 Then
            soulPlayer.Left -= 1.5 / moveSpeed
        End If
        If GetAsyncKeyState(Keys.S) <> 0 And soulStop <> 1 And soulPlayer.Top >= 120 Then
            Me.Top += 0.75 / moveSpeed
        ElseIf GetAsyncKeyState(Keys.S) And soulStop <> 1 Then
            soulPlayer.Top += 1.5 / moveSpeed
        End If
        If GetAsyncKeyState(Keys.D) <> 0 And soulStop <> 1 And soulPlayer.Left >= 120 Then
            Me.Left += 0.75 / moveSpeed
        ElseIf GetAsyncKeyState(Keys.D) And soulStop <> 1 Then
            soulPlayer.Left += 1.5 / moveSpeed
        End If
        If GetAsyncKeyState(Keys.Z) <> 0 And soulStop <> 1 Then
            moveSpeed = 2
        Else
            moveSpeed = 1
        End If
        If Not IsWindowOnScreen() Then
            offScreen = True
        End If
        If offScreen = True Then
            soulStop = 1
            My.Computer.Audio.Play("C:\Users\banan\source\repos\OnYourOwn Solution\OnYourOwn Project\Resources\flee.wav", AudioPlayMode.Background)
            Thread.Sleep(2000)
            Me.Close()
        End If
    End Sub
    Private Sub particleTimer_Tick(
    sender As Object,
    e As EventArgs
) Handles particleTimer.Tick

        For i As Integer = particles.Count - 1 To 0 Step -1

            Dim particle As SoulParticle = particles(i)

            ' Apply gravity
            particle.VelocityY += particle.Gravity

            ' Update particle position
            particle.PositionX += particle.VelocityX
            particle.PositionY += particle.VelocityY

            ' Move the PictureBox
            particle.Sprite.Location = New Point(
                CInt(particle.PositionX),
                CInt(particle.PositionY)
            )

            ' Remove particles when they leave the screen
            If particle.PositionY > Me.ClientSize.Height Then

                Me.Controls.Remove(particle.Sprite)

                particle.Sprite.Dispose()

                particles.RemoveAt(i)

            End If

        Next

        If particles.Count = 0 Then
            particleTimer.Stop()
        End If

    End Sub
End Class